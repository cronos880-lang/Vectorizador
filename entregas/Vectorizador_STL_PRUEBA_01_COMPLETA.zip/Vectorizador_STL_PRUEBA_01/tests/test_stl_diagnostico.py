"""Regresión de extrusión STL: diagnósticos sin cambios geométricos silenciosos.

Ejecutar: python -m unittest discover -s tests -p 'test_stl_diagnostico.py'
"""
import unittest

from motor.extrusion_stl import construir_stl


def exterior():
    return {'id': 'exterior', 'tipo': 'rectangle', 'capa': 'CONTORNO_EXTERIOR',
            'a': [0.0, 0.0], 'b': [50.0, 50.0]}


def agujero(ident, x, y, radio):
    return {'id': ident, 'tipo': 'circle', 'capa': 'AGUJEROS',
            'cx': x, 'cy': y, 'radio': radio}


class DiagnosticoSTLTest(unittest.TestCase):
    def test_extruye_grosor_2_5_mm_con_agujero(self):
        raw, meta = construir_stl([exterior(), agujero('agujero-1', 25, 25, 4)], 2.5)
        self.assertGreater(len(raw), 84)
        self.assertEqual(meta['grosor_mm'], 2.5)
        self.assertEqual(meta['piezas'], 1)
        self.assertAlmostEqual(meta['ancho_mm'], 50.0)
        self.assertAlmostEqual(meta['alto_mm'], 50.0)

    def test_circulo_espurio_se_identifica_sin_borrarlo(self):
        entidades = [exterior(), agujero('normal', 25, 25, 4),
                     agujero('ruido', 60, 30, 0.031275)]
        with self.assertRaisesRegex(ValueError, 'Entidad 3 .*ruido.*0\\.0313'):
            construir_stl(entidades, 2.5)
        self.assertEqual(len(entidades), 3)

    def test_reparacion_experimental_conserva_cad(self):
        entidades = [exterior(), agujero('cruza', 2, 25, 4),
                     agujero('ruido', 60, 30, 0.031275)]
        original = [dict(e) for e in entidades]
        data, meta = construir_stl(entidades, 2.5, reparacion_prueba=True)
        self.assertGreater(len(data), 84)
        self.assertEqual(meta['grosor_mm'], 2.5)
        self.assertEqual(len(meta['reparaciones_prueba']), 2)
        self.assertEqual(entidades, original)

    def test_estricto_sigue_rechazando_esos_mismos_errores(self):
        entidades = [exterior(), agujero('cruza', 2, 25, 4),
                     agujero('ruido', 60, 30, 0.031275)]
        with self.assertRaisesRegex(ValueError, 'Geometría STL inválida'):
            construir_stl(entidades, 2.5)

    def test_contornos_duplicados_no_entran_en_bucle(self):
        entidades = [exterior(), agujero('duplicado-a', 25, 25, 4),
                     agujero('duplicado-b', 25, 25, 4)]
        with self.assertRaisesRegex(ValueError, 'Contornos 2 y 3 duplicados'):
            construir_stl(entidades, 2.5)

    def test_agujero_fuera_no_se_convierte_en_segundo_solido(self):
        entidades = [exterior(), agujero('fuera', 65, 25, 3)]
        with self.assertRaisesRegex(ValueError, 'El agujero 2 .*fuera.*está fuera'):
            construir_stl(entidades, 2.5)

    def test_informa_varios_errores_en_una_sola_revision(self):
        entidades = [exterior(), agujero('cruza', 2, 25, 4),
                     agujero('ruido', 60, 30, 0.031275)]
        with self.assertRaises(ValueError) as ex:
            construir_stl(entidades, 2.5)
        self.assertIn('Entidad 3', str(ex.exception))
        self.assertIn('el agujero 2 sobresale', str(ex.exception))

    def test_agujero_que_cruza_borde_identifica_entidades(self):
        entidades = [exterior(), agujero('cerca-del-borde', 2, 25, 4)]
        with self.assertRaisesRegex(ValueError, 'Contornos 1 y 2.*el agujero 2 sobresale'):
            construir_stl(entidades, 2.5)


if __name__ == '__main__':
    unittest.main()
